<?php 
session_start();
if (!isset($_SESSION['gm_video'])) {
    header("Location: /index.php");
    exit();
}
// Tambahkan logika logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: /index.php");
    exit();
}
include "../404/pro.php";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Live</title>
    <link rel="stylesheet" href="style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://unpkg.com/peerjs@1.5.2/dist/peerjs.min.js"></script>
</head>
<body>
    <div class="container">
        <h1>Video Live</h1>
<div class="d-flex justify-content-between align-items-center mb-4 mt-4 ms-3 text-center" style="max-width: 500px; width: 90%;">
    <button onclick='location.href="<?php echo basename($_SERVER['PHP_SELF']); ?>"' class="btn btn-secondary btn-glass me-2 flex-fill">Home</button>
    <button onclick='location.href="/index.php"' class="btn btn-secondary btn-glass me-2 flex-fill">Video Call</button>
    <button onclick='location.href="?logout=1"' class="btn btn-secondary btn-glass flex-fill">Logout</button>
</div>
        <div id="setup-area" class="setup-area">
            <input type="text" id="username-input" placeholder="Masukkan nama Anda...">
            <div class="room-controls">
                <button id="create-room-btn">Buat Room Baru</button>
            </div>
                <div class="join-room">
                    <input type="text" id="room-id-input" placeholder="Masukkan ID Room untuk bergabung">
                    <button id="join-room-btn">Gabung</button>
                </div>
        </div>

        <div id="call-area" class="call-area hidden">
            <h2 id="room-info"></h2>
            <div class="sharing-area">
                <p>Bagikan link ini ke teman Anda:</p>
                <input type="text" id="share-link-input" readonly>
				  <div class="text-end">
                    <button class="rounded" id="copy-link-btn">Salin Link</button>
                  </div>
                <div class="share-buttons">
                    <a id="whatsapp-share" href="#" target="_blank">WhatsApp</a>
                    <a id="telegram-share" href="#" target="_blank">Telegram</a>
                </div>
            </div>

            <div id="video-grid" class="video-grid">
                </div>

            <div class="chat-container">
                <h3>Chat Room</h3>
                <div id="chat-box" class="chat-box">
                    </div>
                <div class="chat-input-area">
                    <input type="text" id="chat-input" placeholder="Ketik pesan...">
                    <button id="send-chat-btn">Kirim</button>
                </div>
            </div>
        </div>
    </div>

    <template id="video-template">
         <div class="video-container">
            <video playsinline autoplay></video>
            <div class="video-label"></div>
        </div>
    </template>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <script src="script.js"></script>
</body>
</html>
