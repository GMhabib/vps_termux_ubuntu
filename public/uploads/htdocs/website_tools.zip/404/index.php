<?php 
header("Location: /cinta/index.php");
?>