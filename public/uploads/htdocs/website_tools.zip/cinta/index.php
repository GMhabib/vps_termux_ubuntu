<!DOCTYPE html>
<html>
<meta charset='UTF-8'/><meta content='width=device-width, initial-scale=1, user-scalable=1, minimum-scale=1, maximum-scale=5' name='viewport'/><meta content='IE=edge' http-equiv='X-UA-Compatible'/>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Shippori+Antique:wght@400;500;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
  <link href="https://htmlku.com/buatkamu/styles.css" rel="stylesheet">

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
  <script src="https://unpkg.com/typeit@8.7.0/dist/index.umd.js"></script>
  <script src="https://kit.fontawesome.com/4f3ce16e3e.js" crossorigin="anonymous"></script>
  
<head>
<title>Page Not Found</title>
<meta name="description" content="HTML Replit Coding">
<!-- 
  Made with love by feeldream!
  
     Blog: https://feeldream.id
     
  Thanks to all <3
-->
</head>
<body>
	
   <!-- Ganti Audio di sini -->
   <audio src="https://feeldreams.github.io/maimuna.mp3" id="linkmp3" class="sembunyi"></audio>
   
   <div id="bodyblur">
     <!-- Wallpaper --><img src="bromo.jpg" id="wallpaper"/><div id="beneranblur"></div>
   </div>
   
   <div id='Content'>

     <div id="loveIn">
       <a href="#" class="lovein">&#10084;</a>
     </div>
     <p id="ket">Sentuh LOVEnya!</p>

     <div class="kumpulanstiker">
         <!-- Stiker untuk Konten -->
         <img src="pandapanah.gif" id="fotostiker"/>
         <img src="bunga.gif" id="fotostiker1"/>
         <img src="gumush.gif" id="fotostiker2"/>
         <img src="g5.gif" id="fotostiker3"/>
         <img src="mmm.gif" id="fotostiker4"/>
         <img src="emawh.gif" id="fotostiker5"/>
     </div>
     
     <p id="utama" class="utama"></p>
     
     <div><blockquote id='bq' data-text=''>
       
       <p id="kalimat"><span style="font-size:15px">Aku Punya Pesan<br>Nih buat Kamu 🫢❤️</span></p>
       <p id="kalimatb"></p>

       <p id="pesan1">Klik 4 LOVE ini! 🫣❤️</p>
       <div id="kolombaru">
         <li id="lv1">❤️</li>
         <li id="lv2">❤️</li>
         <li id="lv3">❤️</li>
         <li id="lv4">❤️</li>
       </div>

       <p id="pesan4" class="sty2b"><b style="font-size:15px">Sehat selalu yaa<br><span class='kuning'>kamu</span> di sana! 🫣</b></p>
       <p id="pesan5" class="sty2b">Jangan pernah telat makan,<br>apalagi telat beribadah...</p>
       <p id="pesan6" class="sty2b">Kalo ngerasa hari ini buruk,<br>percayalah semua akan<br>cepat berlalu... 🫶</p>
       <p id="pesan7" class="sty2b left"><span class='kuning bold'>Terakhir</span>,<br><br>Aku tidak mau ada sesuatu hal yang membuat <span class='merahmuda'>senyumanmu</span> hilang, dan semoga selalu ada jalan untuk menggapai impian yang pernah kamu ceritakan dan semoga proses tidak mengkhianati hasilnya... 💐</p>
       <p id="pesan8" class="sty2b left"><b>Semangat yaa 🫣😍💗</b></p>

       <!-- Tombol Lanjut -->
       <p id="opsL">Klik untuk Lanjut</p>
     </blockquote></div>

   </div>

<script src="script.js"></script>
</body>
</html>